/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbstress.jsqlparserv3;

import java.io.StringReader;
import java.util.Scanner;
import net.sf.jsqlparser.JSQLParserException;
import net.sf.jsqlparser.parser.CCJSqlParserManager;
import net.sf.jsqlparser.parser.CCJSqlParserUtil;
import net.sf.jsqlparser.statement.Statement;
import net.sf.jsqlparser.statement.StatementVisitor;
import net.sf.jsqlparser.statement.Statements;

/**
 *
 * @author Lukas Hanusek
 */
public class DBStressJsqlparserv3 {
    public static void main(String[] args) {
       System.out.println("Type SQL to check and hit enter.");
       Scanner sc = new Scanner(System.in);
       String line = sc.nextLine();
       while (line != null) {
            long start = System.currentTimeMillis();
            long nano = System.nanoTime();
            System.out.println("Result: " + parse(line) + ", took: " + (System.currentTimeMillis() - start) + "ms, " + (System.nanoTime()-nano) + "ns");
            line = sc.nextLine();
        }
    }

    public static boolean parse(String sql) {
        
        try {
            Statements st = CCJSqlParserUtil.parseStatements(sql);
            st.getStatements().get(0);
            
      /*      
            CCJSqlParserManager parserManager = new CCJSqlParserManager();
StatementVisitor statementVisitor = new StmntVisitorImpl ();
Statement sqlStatement =  parserManager.parse(new StringReader(sql));
sqlStatement.accept(statementVisitor);
            */
            
            return true;
        } catch (JSQLParserException ex) {
            System.out.println(ex.getCause().getMessage());
            return false;
        }
    }
    
}

package mysql.plugin;

import dbstresstest.plugins.DbPool;
import java.sql.Connection;
import java.sql.SQLException;
import org.apache.commons.dbcp2.BasicDataSource;

/**
 *
 * @author Lukas Hanusek
 */
public class MySQLPool implements DbPool {
    
    private BasicDataSource dataSource;

    /**
     * During the object creation the connection pool is created, if fails
     * exception is thrown and obejct is nto created
     *
     * @param uri
     * @param user
     * @param password
     * @param maxConnections
     * @throws Exception
     */
    public MySQLPool setup(String driver, String uri, String user, String password, int maxConnections) throws Exception {
        if (this.dataSource == null) {
            BasicDataSource ds = new BasicDataSource();
            ds.setDriverClassName(Main.driver);
            ds.setUrl(uri);
            ds.setUsername(user);
            ds.setPassword(password);
            ds.setMaxTotal(maxConnections);
            ds.setMaxWaitMillis(2000);
            this.dataSource = ds;
        }
        return this;
    }

    public void close() throws Exception {
        dataSource.close();
    }

    /**
     * Maximum amount of concurrently active db connections
     *
     * @return
     */
    public int getPoolMaxActive() {
        return dataSource.getMaxTotal();
    }

    /**
     * Current amount of active conenctions
     *
     * @return
     */
    public int getPoolActive() {
        return dataSource.getNumActive();
    }

    /**
     * Connections that have been used previously (or reused several times) but
     * are currently in sleep mode
     *
     * @return
     */
    public int getPoolIdle() {
        return dataSource.getNumIdle();
    }
    
    /**
     * Get conenction
     * @return
     * @throws SQLException 
     */
    public Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }
    
}

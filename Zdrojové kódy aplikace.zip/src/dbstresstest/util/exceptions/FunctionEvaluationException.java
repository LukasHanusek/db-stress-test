/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbstresstest.util.exceptions;

/**
 *
 * @author Dakado
 */
public class FunctionEvaluationException extends Exception {
    
    public FunctionEvaluationException() {
        super();
    }
    
    public FunctionEvaluationException(String message) {
        super(message);
    }
    
}

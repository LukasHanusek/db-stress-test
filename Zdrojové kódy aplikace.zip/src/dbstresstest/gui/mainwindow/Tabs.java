/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbstresstest.gui.mainwindow;

/**
 *
 * @author Dakado
 */
public class Tabs {
    
    public static final int CONNECTIONS = 0;
    public static final int SETS = 1;
    public static final int TASKS = 2;
    
    
    public static final String CONNECTIONS_TEXT = "Connections";
    public static final String SETS_TEXT = "SQL";
    public static final String TASKS_TEXT = "Tasks";
    
}

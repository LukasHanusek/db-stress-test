/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbstresstest.logic.runnable;

/**
 *
 * @author Lukas Hanusek
 */
public class TaskEventListener {
    
    
    public void onStart() {
        
    }
    
    public void onStop() {
        
    }
    
    public void onConsoleLog(String message) {
        
    }
    
    public void onQuery() {
        
    }
    
    public void onLoop() {
        
    }
    
    public void onError() {
        
    }
    
    public void onLoopEnd() {
        
    }
    
}

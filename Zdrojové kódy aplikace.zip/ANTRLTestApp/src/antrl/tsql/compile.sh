java -cp antlr-4.7.1-complete.jar org.antlr.v4.Tool TSqlLexer.g4 -visitor
java -cp antlr-4.7.1-complete.jar org.antlr.v4.Tool TSqlParser.g4 -visitor
PAUSE

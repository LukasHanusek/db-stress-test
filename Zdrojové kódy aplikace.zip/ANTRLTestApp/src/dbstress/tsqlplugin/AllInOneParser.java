package dbstress.tsqlplugin;

import antrl.mysql.MySqlParser;
import antrl.mysql.MySqlLexer;
import antrl.mysql.MySqlParserBaseListener;
import antrl.plsql.PlSqlLexer;
import antrl.plsql.PlSqlParser;
import antrl.tsql.TSqlLexer;
import antrl.tsql.TSqlParser;
import antrl.tsql.TSqlParserBaseListener;
import java.util.Scanner;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.atn.ParseInfo;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeWalker;

/**
 *
 * @author Lukas Hanusek
 */
public class AllInOneParser {

    /**
     * THIS  CODE MUST BE RUN FROM .BAT FILE OR .SH IN LINUX, CANNOT BE RUN FROM NETBEANS OR ANY OTHER IDE
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       System.out.println("Type SQL to check and hit enter.");
       Scanner sc = new Scanner(System.in);
       String line = sc.nextLine();
       while (line != null) {
           line = line.toUpperCase();

           boolean plsql = plsql(line);
           boolean mysql = mysql(line);
           boolean tsql = tsql(line);
           
           
           line = sc.nextLine();
       }
    }
    
    static boolean mysqlresult = true;

    public static boolean mysql(String args) {
        mysqlresult = true;
        long start = System.currentTimeMillis();
        System.out.println("MySQL Check: " + args);
        CharStream stream = new ANTLRInputStream(args);
        MySqlLexer lexer = new MySqlLexer(stream);
        CommonTokenStream tokens = new CommonTokenStream(lexer);

        MySqlParser parser = new MySqlParser(tokens);

        parser.addErrorListener(new BaseErrorListener() {
            @Override
            public void syntaxError(Recognizer<?, ?> recognizer, Object offendingSymbol, int line, int pos, String msg, RecognitionException e) {
                System.out.println("Failed to parse at " + line + "," + pos + ":  " + msg);
                //if (!msg.contains("<EOF>")) { //ANTRL BUG IGNORE IT 
                    mysqlresult = false;
                //}
            }
        });

        parser.dmlStatement().toStringTree(parser);
        
        /*ParseTree tree = parser.dmlStatement();
        ParseTreeWalker walker = new ParseTreeWalker();
        MySqlParserBaseListener listener = new MySqlParserBaseListener();
        
        ParseTreeWalker.DEFAULT.walk(listener, tree);*/
        System.out.println("MySQL Result: " + mysqlresult + ", took: " + (System.currentTimeMillis()-start) + "ms");
        return mysqlresult;
    }
    
    static boolean tsqlresult = true;

    public static boolean tsql(String args) {
        tsqlresult = true;
        long start = System.currentTimeMillis();
        System.out.println("TSQL Check: " + args);
        CharStream stream = new ANTLRInputStream(args);
        TSqlLexer lexer = new TSqlLexer(stream);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        
        TSqlParser parser = new TSqlParser(tokens);

        parser.addErrorListener(new BaseErrorListener() {
            @Override
            public void syntaxError(Recognizer<?, ?> recognizer, Object offendingSymbol, int line, int pos, String msg, RecognitionException e) {
                System.out.println("Failed to parse at " + line + "," + pos + ":  " + msg);
                //if (!msg.contains("<EOF>")) { //ANTRL BUG IGNORE IT 
                    tsqlresult = false;
                //}
            }
        });

        parser.dml_clause().toStringTree(parser);

        /*ParseTree tree = parser.dml_clause();
        ParseTreeWalker walker = new ParseTreeWalker();
        TSqlParserBaseListener listener = new TSqlParserBaseListener();
        ParseTreeWalker.DEFAULT.walk(listener, tree);*/
        
        System.out.println("TSQL Result: " + tsqlresult + ", took: " + (System.currentTimeMillis()-start) + "ms");
        return tsqlresult;
    }
    
    
    
    static boolean plsqlresult = true;

    public static boolean plsql(String args) {
        plsqlresult = true;
        long start = System.currentTimeMillis();
        System.out.println("PLSQL Check: " + args);
        CharStream stream = new ANTLRInputStream(args);
        PlSqlLexer lexer = new PlSqlLexer(stream);
        CommonTokenStream tokens = new CommonTokenStream(lexer);

        PlSqlParser parser = new PlSqlParser(tokens);

        parser.addErrorListener(new BaseErrorListener() {
            @Override
            public void syntaxError(Recognizer<?, ?> recognizer, Object offendingSymbol, int line, int pos, String msg, RecognitionException e) {
                System.out.println("Failed to parse at " + line + "," + pos + ":  " + msg);
                //if (!msg.contains("<EOF>")) { //ANTRL BUG IGNORE IT 
                    plsqlresult = false;
                //}
            }
        });
        
        parser.data_manipulation_language_statements().toStringTree();
        
        System.out.println("PLSQL Result: " + plsqlresult + ", took: " + (System.currentTimeMillis()-start) + "ms");

        return plsqlresult;
    }


}

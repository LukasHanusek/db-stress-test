/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package h2.plugin;

import dbstresstest.plugins.DbPool;
import java.sql.Connection;
import java.sql.SQLException;
import org.h2.jdbcx.JdbcConnectionPool;

/**
 *
 * @author Lukas Hanusek
 */
public class H2Pool implements DbPool {
    
    private JdbcConnectionPool cp;

    @Override
    public DbPool setup(String driver, String uri, String user, String password, int maxConnections) throws Exception {
        cp = JdbcConnectionPool.create(uri, user, password);
        cp.setMaxConnections(maxConnections);
        return this;
    }

    @Override
    public void close() throws Exception {
        cp.dispose();
    }

    @Override
    public int getPoolMaxActive() {
        return cp.getMaxConnections();
    }

    @Override
    public int getPoolActive() {
        return cp.getActiveConnections();
    }

    @Override
    public int getPoolIdle() {
        return 0;
    }

    @Override
    public Connection getConnection() throws SQLException {
        return cp.getConnection();
    }
    
}

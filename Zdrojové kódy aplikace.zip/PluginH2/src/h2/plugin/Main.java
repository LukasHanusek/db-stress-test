/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package h2.plugin;

import dbstresstest.plugins.DatabasePlugin;
import dbstresstest.plugins.DbPool;
import dbstresstest.plugins.ParseError;
import net.sf.jsqlparser.JSQLParserException;
import net.sf.jsqlparser.parser.CCJSqlParserUtil;
import net.sf.jsqlparser.statement.Statements;

/**
 *
 * @author Lukas Hanusek
 */
public class Main extends DatabasePlugin {
    
     public static final String driver = "org.h2.Driver";
    
    
    public Main() {
        System.out.println("H2 Plugin loaded!");
    }
    
    @Override
    public DbPool getPool() {
        return new H2Pool();
    }

    /**
     * Plugin name
     * @return 
     */
    @Override
    public String getName() {
        return "H2";
    }
    
    /**
     * Get driver class path for this type of database
     * @return
     * @throws ClassNotFoundException 
     */
    @Override
    public String getDriver() throws ClassNotFoundException {
        return driver;
    }
    
    /**
     * Example: jdbc:mysql://%ADDRESS%:%PORT%/%DB_NAME%
     * Variables:
     *  %ADDRESS% - database address
     *  %PORT% - database port
     *  %DB_NAME% - schema or database name (depending on db)
     * @return 
     */
    @Override
    public String getURIFormat() {     
        return "jdbc:h2:tcp://%ADDRESS%:%PORT%/~/%DB_NAME%";
    }
    
    @Override
    public ParseError parse(String sql) {
        try {
            Statements st = CCJSqlParserUtil.parseStatements(sql);
            st.getStatements().get(0);
            return null;
        } catch (JSQLParserException ex) {
            ParseError pe = new ParseError();
            pe.setMessage(ex.getCause().getMessage());
            try {
                pe.setLine(Integer.valueOf(ex.getCause().getMessage().split("at line ")[1].split(",")[0]));
            } catch (Exception e) {
                pe.setLine(0);
            }
            try {
            pe.setPosition(Integer.valueOf(ex.getCause().getMessage().split("column ")[1].split(".")[0]));
            } catch (Exception e) {
                pe.setPosition(0);
            }
            System.out.println(ex.getCause().getMessage());
            return pe;
        }
    } 
    
}
